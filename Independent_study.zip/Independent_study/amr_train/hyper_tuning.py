import os
import subprocess
import itertools
import argparse
import pandas as pd

# ------------------------------
# Define Hyperparameter Grid
# ------------------------------
learning_rates = [1e-5, 2e-5, 3e-5]
weight_decays = [0.0, 0.1, 0.2]
dropouts = [0.1, 0.2]

hyperparameter_grid_bart = list(itertools.product(learning_rates, weight_decays, dropouts))
hyperparameter_grid_t5 = list(itertools.product(learning_rates, weight_decays))

# ------------------------------
# Train BART Model
# ------------------------------
def train_bart(hyperparams, train_file, val_file, output_dir):
    lr, wd, dropout = hyperparams
    run_name = f"bart_lr{lr}_wd{wd}_do{dropout}"
    model_output = os.path.join(output_dir, run_name)

    print(f"\n🔹 Training BART with LR={lr}, WD={wd}, Dropout={dropout}")
    print(f"📁 Saving to: {model_output}")

    train_cmd = [
        "python", "bart_train.py",
        "--train_file", train_file,
        "--validation_file", val_file,
        "--output_dir", model_output,
        "--model_name", "facebook/bart-base",
        "--learning_rate", str(lr),
        "--weight_decay", str(wd),
        "--dropout", str(dropout)
    ]

    subprocess.run(train_cmd, check=True)
    return model_output

# ------------------------------
# Train T5 Model
# ------------------------------
def train_t5(hyperparams, train_file, val_file, output_dir):
    lr, wd = hyperparams
    run_name = f"t5_lr{lr}_wd{wd}"
    model_output = os.path.join(output_dir, run_name)

    print(f"\n🔹 Training T5 with LR={lr}, WD={wd}")
    print(f"📁 Saving to: {model_output}")

    train_cmd = [
        "python", "T5_train.py",
        "--train_file", train_file,
        "--validation_file", val_file,
        "--output_dir", model_output,
        "--model_name", "t5-small",
        "--learning_rate", str(lr),
        "--weight_decay", str(wd)
    ]

    subprocess.run(train_cmd, check=True)
    return model_output

# ------------------------------
# Evaluate Model
# ------------------------------
def evaluate_model(model_type, model_dir, test_file, output_dir):
    output_file = os.path.join(output_dir, f"{os.path.basename(model_dir)}_results.json")

    print(f"\n🔹 Evaluating {model_type.upper()} - Model: {model_dir}")

    eval_cmd = [
        "python", "gen_and_eval.py",
        "--test_file", test_file,
        "--output_dir", model_dir,
        "--output_file", output_file,
        "--model_type", model_type
    ]

    subprocess.run(eval_cmd, check=True)
    return output_file

# ------------------------------
# Main Function
# ------------------------------
def main():
    parser = argparse.ArgumentParser(description="Hyperparameter tuning for BART and T5.")
    parser.add_argument("--train_file", type=str, required=True)
    parser.add_argument("--val_file", type=str, required=True)
    parser.add_argument("--test_file", type=str, required=True)
    parser.add_argument("--output_dir", type=str, required=True)
    parser.add_argument("--model_type", type=str, choices=["bart", "t5", "both"], default="bart")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    results = []

    if args.model_type in ["bart", "both"]:
        for hyperparams in hyperparameter_grid_bart:
            try:
                model_path = train_bart(hyperparams, args.train_file, args.val_file, args.output_dir)
                eval_path = evaluate_model("bart", model_path, args.test_file, args.output_dir)

                results.append({
                    "model": "BART",
                    "learning_rate": hyperparams[0],
                    "weight_decay": hyperparams[1],
                    "dropout": hyperparams[2],
                    "model_path": model_path,
                    "eval_results": eval_path
                })

            except subprocess.CalledProcessError as e:
                print(f"❌ Failed for BART config {hyperparams}: {e}")
                continue

    if args.model_type in ["t5", "both"]:
        for hyperparams in hyperparameter_grid_t5:
            try:
                model_path = train_t5(hyperparams, args.train_file, args.val_file, args.output_dir)
                eval_path = evaluate_model("t5", model_path, args.test_file, args.output_dir)

                results.append({
                    "model": "T5",
                    "learning_rate": hyperparams[0],
                    "weight_decay": hyperparams[1],
                    "dropout": None,
                    "model_path": model_path,
                    "eval_results": eval_path
                })

            except subprocess.CalledProcessError as e:
                print(f"❌ Failed for T5 config {hyperparams}: {e}")
                continue

    # Save results to CSV
    results_df = pd.DataFrame(results)
    results_csv = os.path.join(args.output_dir, "hyperparameter_results.csv")
    results_df.to_csv(results_csv, index=False)

    print(f"\n✅ Grid search results saved to: {results_csv}")

if __name__ == "__main__":
    main()



#python hyperparameter_tuning.py --model_type bart --train_file ./data/amr_train.json --val_file ./data/amr_dev.json --test_file ./data/amr_test.json --output_dir ./models/bart_only

#python hyperparameter_tuning.py --model_type t5 --train_file ./data/amr_train.json --val_file ./data/amr_dev.json --test_file ./data/amr_test.json --output_dir ./models/t5_only

#python hyperparameter_tuning.py --train_file ./data/amr_train.json --val_file ./data/amr_dev.json --test_file ./data/amr_test.json --output_dir ./models/both_models