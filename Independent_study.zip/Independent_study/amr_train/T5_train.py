import penman
import torch
import json
import argparse
import os
from transformers import T5Tokenizer, T5ForConditionalGeneration, Trainer, TrainingArguments
from torch.utils.data import Dataset

# ------------------------------
# AMR Preprocessing Function
# ------------------------------
def preprocess_amr(amr_string):
    """
    Preprocesses the AMR string by parsing and serializing it to ensure correctness.
    
    Parameters:
        amr_string (str): The AMR graph as a string.
        
    Returns:
        str or None: The preprocessed AMR string if successful, else None.
    """
    try:
        graph = penman.decode(amr_string)
        return penman.encode(graph)
    except penman.errors.PenmanError as e:
        print(f"Error in AMR parsing: {e}")
        return None

# ------------------------------
# AMR Dataset Class
# ------------------------------
class AMRDataset(Dataset):
    def __init__(self, data_list, tokenizer, max_length=256):
        """
        Initializes the dataset with AMR-sentence pairs.
        
        Parameters:
            data_list (list): List of dictionaries containing 'amr' and 'sent' keys.
            tokenizer (T5Tokenizer): The T5 tokenizer.
            max_length (int): Maximum sequence length for tokenization.
        """
        self.data_list = data_list
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.data_list)

    def __getitem__(self, idx):
        data = self.data_list[idx]
        amr_string = data["amr"]
        sentence = data["sent"]

        # Preprocess AMR
        preprocessed_amr = preprocess_amr(amr_string) or ""

        # Define the task prefix as per T5's format
        task_prefix = "translate AMR to text: "

        # Tokenize inputs and outputs
        input_text = task_prefix + preprocessed_amr
        target_text = sentence

        input_encoding = self.tokenizer(
            input_text,
            truncation=True,
            padding='max_length',
            max_length=self.max_length,
            return_tensors='pt'
        )
        target_encoding = self.tokenizer(
            target_text,
            truncation=True,
            padding='max_length',
            max_length=self.max_length,
            return_tensors='pt'
        )

        labels = target_encoding['input_ids']
        labels[labels == self.tokenizer.pad_token_id] = -100  # Ignore padding in loss

        return {
            'input_ids': input_encoding['input_ids'].squeeze(),
            'attention_mask': input_encoding['attention_mask'].squeeze(),
            'labels': labels.squeeze()
        }

# ------------------------------
# JSON File Loader
# ------------------------------
def load_json(filepath):
    """Loads a JSON file."""
    with open(filepath, 'r', encoding='utf-8') as f:
        return json.load(f)

# ------------------------------
# Main Function
# ------------------------------
def main():
    parser = argparse.ArgumentParser(description="Fine-tune T5 on AMR-to-Text data.")
    parser.add_argument('--train_file', type=str, required=True, help='Path to the training JSON file.')
    parser.add_argument('--validation_file', type=str, required=True, help='Path to the validation JSON file.')
    parser.add_argument('--output_dir', type=str, required=True, help='Directory to save the fine-tuned model.')
    parser.add_argument('--model_name', type=str, default='t5-small', help='Pre-trained T5 model name (e.g., t5-small, t5-base, t5-large).')
    parser.add_argument('--max_length', type=int, default=256, help='Maximum sequence length for tokenization.')
    parser.add_argument('--num_train_epochs', type=int, default=3, help='Number of training epochs.')
    parser.add_argument('--per_device_train_batch_size', type=int, default=8, help='Batch size per device during training.')
    parser.add_argument('--per_device_eval_batch_size', type=int, default=8, help='Batch size per device during evaluation.')
    parser.add_argument('--learning_rate', type=float, default=5e-5, help='Learning rate.')
    parser.add_argument('--weight_decay', type=float, default=0.01, help='Weight decay.')
    parser.add_argument('--warmup_steps', type=int, default=500, help='Warmup steps for the learning rate scheduler.')

    args = parser.parse_args()

    # Ensure output directory exists
    os.makedirs(args.output_dir, exist_ok=True)

    # Load datasets
    train_data = load_json(args.train_file)
    validation_data = load_json(args.validation_file)

    # Initialize tokenizer and model
    tokenizer = T5Tokenizer.from_pretrained(args.model_name)
    model = T5ForConditionalGeneration.from_pretrained(args.model_name)

    # Create Dataset objects
    train_dataset = AMRDataset(train_data, tokenizer, max_length=args.max_length)
    val_dataset = AMRDataset(validation_data, tokenizer, max_length=args.max_length)

    # Define training arguments
    training_args = TrainingArguments(
        output_dir=args.output_dir,
        num_train_epochs=args.num_train_epochs,
        per_device_train_batch_size=args.per_device_train_batch_size,
        per_device_eval_batch_size=args.per_device_eval_batch_size,
        save_strategy='epoch',
        save_total_limit=3,
        logging_steps=500,
        evaluation_strategy='epoch',
        learning_rate=args.learning_rate,
        weight_decay=args.weight_decay,
        warmup_steps=args.warmup_steps,
        load_best_model_at_end=True,
        metric_for_best_model='loss',
        greater_is_better=False,
        fp16=torch.cuda.is_available(),
    )

    # Initialize Trainer
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=val_dataset,
    )

    # Train the model
    trainer.train()

    # Save the fine-tuned model
    trainer.save_model(args.output_dir)
    tokenizer.save_pretrained(args.output_dir)
    print(f"Fine-tuned model saved to {args.output_dir}")

if __name__ == "__main__":
    main()


# python T5_train.py train_file "./data/amr_train.json" validation_file "./data/amr_dev.json" output_dir "./models/t5_finetuned"
