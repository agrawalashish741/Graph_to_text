import penman
import torch
import json
import argparse
import os
from transformers import BartTokenizer, BartForConditionalGeneration, T5Tokenizer, T5ForConditionalGeneration
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
from rouge_score import rouge_scorer
from tqdm import tqdm  # <-- Added for progress bar

# ------------------------------
# AMR Preprocessing Function
# ------------------------------
def preprocess_amr(amr_string):
    try:
        graph = penman.decode(amr_string)
        return penman.encode(graph)
    except penman.errors.PenmanError as e:
        print(f"Error in AMR parsing: {e}")
        return None

# ------------------------------
# JSON File Loader
# ------------------------------
def load_json(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        return json.load(f)

# ------------------------------
# BLEU Score Calculation
# ------------------------------
def compute_bleu(reference, candidate):
    reference_tokens = reference.split()
    candidate_tokens = candidate.split()
    smoothing = SmoothingFunction().method1
    return sentence_bleu([reference_tokens], candidate_tokens, smoothing_function=smoothing)

# ------------------------------
# ROUGE Score Calculation
# ------------------------------
def compute_rouge(reference, candidate):
    scorer = rouge_scorer.RougeScorer(['rouge1', 'rouge2', 'rougeL'], use_stemmer=True)
    scores = scorer.score(reference, candidate)
    return {
        'rouge1': scores['rouge1'].fmeasure,
        'rouge2': scores['rouge2'].fmeasure,
        'rougeL': scores['rougeL'].fmeasure
    }

# ------------------------------
# Sentence Generation
# ------------------------------
def generate_sentence_from_amr(amr_string, tokenizer, model, device, model_type="bart", max_length=256):
    preprocessed_amr = preprocess_amr(amr_string) or "Invalid AMR"

    if model_type.lower() == "t5":
        input_text = "translate AMR to text: " + preprocessed_amr
    else:
        input_text = preprocessed_amr

    inputs = tokenizer(
        input_text,
        return_tensors='pt',
        truncation=True,
        max_length=max_length
    )
    inputs = {k: v.to(device) for k, v in inputs.items()}

    with torch.no_grad():
        generated_ids = model.generate(
            input_ids=inputs['input_ids'],
            attention_mask=inputs['attention_mask'],
            max_length=max_length,
            num_beams=5,
            early_stopping=True,
            no_repeat_ngram_size=2,
            do_sample=False
        )

    return tokenizer.decode(generated_ids[0], skip_special_tokens=True)

# ------------------------------
# Main Function
# ------------------------------
def main():
    parser = argparse.ArgumentParser(description="Generate and evaluate sentences from AMR using a fine-tuned model.")
    parser.add_argument('--test_file', type=str, required=True, help='Path to the test JSON file.')
    parser.add_argument('--output_dir', type=str, required=True, help='Directory where the fine-tuned model is saved.')
    parser.add_argument('--output_file', type=str, required=True, help='Path to save the generation results.')
    parser.add_argument('--model_type', type=str, choices=['bart', 't5'], required=True, help="Specify the model type: 'bart' or 't5'.")
    parser.add_argument('--max_length', type=int, default=256, help='Maximum sequence length for generation.')

    args = parser.parse_args()

    os.makedirs(os.path.dirname(args.output_file), exist_ok=True)

    print("🔍 Loading test data...")
    test_data = load_json(args.test_file)

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"📦 Loading model and tokenizer from {args.output_dir} on device {device}...")

    if args.model_type.lower() == "t5":
        tokenizer = T5Tokenizer.from_pretrained("t5-base")
        model = T5ForConditionalGeneration.from_pretrained(args.output_dir)
    else:
        tokenizer = BartTokenizer.from_pretrained("facebook/bart-base")
        model = BartForConditionalGeneration.from_pretrained(args.output_dir)

    model.to(device)

    total_bleu, total_rouge1, total_rouge2, total_rougeL, valid_count = 0, 0, 0, 0, 0
    results = []

    print("🚀 Starting generation and evaluation...\n")
    for data in tqdm(test_data, desc="Processing"):
        amr_string = data["amr"]
        reference_sentence = data["sent"]

        generated_sentence = generate_sentence_from_amr(
            amr_string, tokenizer, model, device, args.model_type, max_length=args.max_length
        )

        if generated_sentence != "Invalid AMR":
            bleu_score = compute_bleu(reference_sentence, generated_sentence)
            rouge_scores = compute_rouge(reference_sentence, generated_sentence)

            total_bleu += bleu_score
            total_rouge1 += rouge_scores['rouge1']
            total_rouge2 += rouge_scores['rouge2']
            total_rougeL += rouge_scores['rougeL']
            valid_count += 1

            results.append({
                'id': data.get('id'),
                'amrID': data.get('amrID'),
                'category': data.get('category'),
                'sent': reference_sentence,
                'amr': amr_string,
                'generated_sent': generated_sentence,
                'bleu_score': bleu_score,
                'rouge1_f1': rouge_scores['rouge1'],
                'rouge2_f1': rouge_scores['rouge2'],
                'rougeL_f1': rouge_scores['rougeL']
            })
        else:
            results.append({
                'id': data.get('id'),
                'amrID': data.get('amrID'),
                'category': data.get('category'),
                'sent': reference_sentence,
                'amr': amr_string,
                'generated_sent': generated_sentence,
                'bleu_score': None,
                'rouge1_f1': None,
                'rouge2_f1': None,
                'rougeL_f1': None
            })

    # Averages
    if valid_count > 0:
        average_bleu = total_bleu / valid_count
        average_rouge1 = total_rouge1 / valid_count
        average_rouge2 = total_rouge2 / valid_count
        average_rougeL = total_rougeL / valid_count
    else:
        average_bleu = average_rouge1 = average_rouge2 = average_rougeL = 0.0

    print("\n📊 Evaluation Summary:")
    print(f"  ✅ BLEU Score: {average_bleu:.4f}")
    print(f"  ✅ ROUGE-1 F1: {average_rouge1:.4f}")
    print(f"  ✅ ROUGE-2 F1: {average_rouge2:.4f}")
    print(f"  ✅ ROUGE-L F1: {average_rougeL:.4f}")

    with open(args.output_file, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=4)

    print(f"\n✅ Results saved to {args.output_file}")

if __name__ == "__main__":
    main()


# python gen_and_eval.py --test_file "./data/amr_test.json" --output_dir "./models/t5_finetuned" --output_file "./results/generated_t5.json" --model_type "t5"

# python generate_and_evaluate.py --test_file "./data/amr_test.json" --output_dir "./models/bart_finetuned" --output_file "./results/generated_bart.json" --model_type "bart"
