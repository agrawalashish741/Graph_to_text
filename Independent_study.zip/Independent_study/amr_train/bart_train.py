import penman
from transformers import BartTokenizer, BartForConditionalGeneration, Trainer, TrainingArguments
import torch
from torch.utils.data import Dataset
import json
import argparse
import os
import wandb

# ------------------------------
# AMR Preprocessing Function
# ------------------------------
def preprocess_amr(amr_string):
    try:
        graph = penman.decode(amr_string)
        return penman.encode(graph)
    except penman.errors.PenmanError as e:
        print(f"Error in AMR parsing: {e}")
        return None

# ------------------------------
# AMR Dataset Class
# ------------------------------
class AMRDataset(Dataset):
    def __init__(self, data_list, tokenizer, max_length=256):
        self.data_list = data_list
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.data_list)

    def __getitem__(self, idx):
        data = self.data_list[idx]
        amr_string = data["amr"]
        sentence = data["sent"]

        preprocessed_amr = preprocess_amr(amr_string)
        if preprocessed_amr is None:
            preprocessed_amr = ""

        input_encoding = self.tokenizer(
            preprocessed_amr,
            truncation=True,
            padding='max_length',
            max_length=self.max_length,
            return_tensors='pt'
        )
        target_encoding = self.tokenizer(
            sentence,
            truncation=True,
            padding='max_length',
            max_length=self.max_length,
            return_tensors='pt'
        )

        labels = target_encoding['input_ids']
        labels[labels == self.tokenizer.pad_token_id] = -100

        return {
            'input_ids': input_encoding['input_ids'].squeeze(),
            'attention_mask': input_encoding['attention_mask'].squeeze(),
            'labels': labels.squeeze()
        }

# ------------------------------
# JSON File Loader
# ------------------------------
def load_json(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        return json.load(f)

# ------------------------------
# Main Training Function
# ------------------------------
def main():
    parser = argparse.ArgumentParser(description="Fine-tune BART on AMR-to-Text dataset.")
    parser.add_argument('--train_file', type=str, required=True)
    parser.add_argument('--validation_file', type=str, required=True)
    parser.add_argument('--output_dir', type=str, required=True)
    parser.add_argument('--model_name', type=str, default='facebook/bart-base')
    parser.add_argument('--max_length', type=int, default=256)
    parser.add_argument('--num_train_epochs', type=int, default=1)
    parser.add_argument('--per_device_train_batch_size', type=int, default=8)
    parser.add_argument('--per_device_eval_batch_size', type=int, default=8)
    parser.add_argument('--learning_rate', type=float, default=5e-5)
    parser.add_argument('--weight_decay', type=float, default=0.01)
    parser.add_argument('--warmup_steps', type=int, default=500)
    parser.add_argument('--dropout', type=float, default=0.1)
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    wandb.init(
        project="bart-amr",
        config={
            "model_name": args.model_name,
            "num_train_epochs": args.num_train_epochs,
            "learning_rate": args.learning_rate,
            "weight_decay": args.weight_decay,
            "train_batch_size": args.per_device_train_batch_size,
            "eval_batch_size": args.per_device_eval_batch_size
        }
    )

    train_data = load_json(args.train_file)
    validation_data = load_json(args.validation_file)

    tokenizer = BartTokenizer.from_pretrained(args.model_name)
    model = BartForConditionalGeneration.from_pretrained(args.model_name)

    if hasattr(model.model.encoder, "dropout"):
        model.model.encoder.dropout = args.dropout
    if hasattr(model.model.decoder, "dropout"):
        model.model.decoder.dropout = args.dropout

    train_dataset = AMRDataset(train_data, tokenizer, max_length=args.max_length)
    val_dataset = AMRDataset(validation_data, tokenizer, max_length=args.max_length)

    training_args = TrainingArguments(
        output_dir=args.output_dir,
        num_train_epochs=args.num_train_epochs,
        per_device_train_batch_size=args.per_device_train_batch_size,
        per_device_eval_batch_size=args.per_device_eval_batch_size,
        save_strategy='no',
        logging_strategy='no',
        evaluation_strategy='no',
        learning_rate=args.learning_rate,
        weight_decay=args.weight_decay,
        warmup_steps=args.warmup_steps,
        load_best_model_at_end=False,
        fp16=torch.cuda.is_available(),
        report_to="wandb"
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=val_dataset,
    )

    trainer.train()
    trainer.save_model(args.output_dir)
    tokenizer.save_pretrained(args.output_dir)
    print(f"✅ Fine-tuned model saved to {args.output_dir}")

if __name__ == "__main__":
    main()



# python bart_train.py --train_file "path/to/train.json" --validation_file "path/to/val.json" --output_dir "path/to/save_model"
