import trankit
import re
import sys
import os

# Ensure the script gets the input filename from the command line
if len(sys.argv) < 3:
    print("Usage: python ud_parser.py <input_text_file> <output_conllu_file>")
    sys.exit(1)

input_file = sys.argv[1]
output_file = sys.argv[2]

# Check if the input file exists
if not os.path.exists(input_file):
    print(f"Error: Input file '{input_file}' not found.")
    sys.exit(1)

# Load Trankit pipeline for English
nlp = trankit.Pipeline(lang="english", gpu=True)

def extract_sentences_from_text(file_path):
    """Reads a text file and extracts sentences using basic sentence segmentation."""
    with open(file_path, "r", encoding="utf-8") as file:
        text = file.read()
    
    # Split paragraphs into sentences using regex (basic sentence segmentation)
    sentences = re.split(r'(?<=[.!?])\s+', text.strip())
    return [s.strip() for s in sentences if s.strip()]

def process_sentence(sentence):
    """
    Processes a single sentence with Trankit and returns CoNLL-U formatted output.
    """
    if not sentence.strip():
        return ""

    try:
        parsed = nlp(sentence)  # Run Trankit

        if "sentences" not in parsed or not parsed["sentences"]:
            print(f"⚠️ Warning: No sentences found in Trankit output. Full output: {parsed}")
            return ""

        tokens_data = parsed["sentences"][0]["tokens"]  # Extract tokens

        conllu_lines = [f"# sentence = {sentence}"]  # Add sentence annotation

        for token in tokens_data:
            token_id = token["id"]
            word = token["text"]
            lemma = token.get("lemma", "-")
            upos = token.get("upos", "-")
            xpos = token.get("xpos", "-")
            feats = token.get("feats", "-")
            head = token.get("head", 0)  # Head word index
            deprel = token.get("deprel", "-")
            
            # Enhanced Dependency Field: `HEAD:DEPREL:CASE_MARKER`
            case_marker = "-"
            if deprel in {"obl", "nmod", "advcl"}:  # Relations that often have case markers
                for tok in tokens_data:
                    if tok["head"] == token_id and tok["deprel"] == "case":
                        case_marker = tok["text"]
                        break
            enhanced_dependency = f"{head}:{deprel}:{case_marker}" if case_marker != "-" else f"{head}:{deprel}"

            # Construct CoNLL-U line
            line = f"{token_id}\t{word}\t{lemma}\t{upos}\t{xpos}\t{feats}\t{head}\t{deprel}\t{enhanced_dependency}\t_"
            conllu_lines.append(line)

        return "\n".join(conllu_lines) + "\n"

    except Exception as e:
        print(f"⚠️ Error processing sentence: {sentence}. Exception: {e}")
        return ""

def process_text_file(input_file, output_file):
    """
    Reads an input text file, extracts sentences, processes them using Trankit,
    and saves the results in CoNLL-U format.
    """
    sentences = extract_sentences_from_text(input_file)

    if not sentences:
        print("⚠️ No valid sentences found in the input file.")
        return

    conllu_output = "\n".join(process_sentence(sent) for sent in sentences if sent)

    # Save the output to a CoNLL-U file
    with open(output_file, "w", encoding="utf-8") as f:
        f.write("# This file was generated using Trankit\n")
        f.write(conllu_output)

    print(f"✅ CoNLL-U file generated: {output_file}")

# Run the processing function
process_text_file(input_file, output_file)

print("✅ Processing complete. Check the output file:", output_file)




# python ud_parser.py sample.txt output.conllu
