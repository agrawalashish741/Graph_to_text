import penman
from collections import deque
import sys
import json

def bfs_linearize_amr(amr_line: str) -> str:
    graph = penman.decode(amr_line)
    triples = graph.triples
    node_concepts = {}
    edges = {}

    for source, role, target in triples:
        if role == ':instance':
            node_concepts[source] = target
            if source not in edges:
                edges[source] = []
        else:
            if source not in edges:
                edges[source] = []
            edges[source].append((role, target))
            if target not in edges:
                edges[target] = []

    root = graph.top
    visited = set()
    queue = deque([root])
    seq = []

    while queue:
        node = queue.popleft()
        if node in visited:
            continue
        visited.add(node)
        concept = node_concepts.get(node, 'UNK')
        seq.append(f"<NODE> {node} {concept}")
        for role, child in edges.get(node, []):
            seq.append(f"<EDGE> {role} {child}")
            queue.append(child)

    return " ".join(seq)

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python bfs_linearize_amr_from_json.py input.json")
        sys.exit(1)

    input_file = sys.argv[1]

    try:
        with open(input_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            for entry in data:
                amr = entry.get("sent", "").strip()
                if amr.startswith("("):  # crude check for AMR format
                    try:
                        result = bfs_linearize_amr(amr)
                        print(result)
                    except Exception as e:
                        print(f"[Error] Could not process AMR: {e}")
                else:
                    print("[Skip] Not an AMR graph:", amr)
    except Exception as e:
        print(f"[Error] Failed to read file: {e}")
        sys.exit(1)

# python bfs_conversion.py amr_input.json