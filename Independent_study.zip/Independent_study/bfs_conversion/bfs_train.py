import json
import torch
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from transformers import BartTokenizer, BartForConditionalGeneration
from tqdm import tqdm
from nltk.translate.bleu_score import corpus_bleu
from rouge import Rouge
import argparse

##############################################
# 1. Custom Dataset for BFS-to-English using BART
##############################################
class AMRBartDataset(Dataset):
    def __init__(self, json_file, tokenizer, max_length=256, target_max_length=256):
        with open(json_file, 'r', encoding='utf-8') as f:
            self.data = json.load(f)
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.target_max_length = target_max_length

    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        record = self.data[idx]
        source_text = record.get("bfs", "")
        target_text = record.get("sent", "")
        source_enc = self.tokenizer(
            source_text,
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        target_enc = self.tokenizer(
            target_text,
            max_length=self.target_max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        return {
            'input_ids': source_enc.input_ids.squeeze(0),
            'attention_mask': source_enc.attention_mask.squeeze(0),
            'labels': target_enc.input_ids.squeeze(0),
            'id': record.get("id"),
            'bfs': source_text,
            'sent': target_text
        }

def collate_fn(batch):
    input_ids = torch.stack([x['input_ids'] for x in batch])
    attention_mask = torch.stack([x['attention_mask'] for x in batch])
    labels = torch.stack([x['labels'] for x in batch])
    ids = [x['id'] for x in batch]
    bfs_list = [x['bfs'] for x in batch]
    sents = [x['sent'] for x in batch]
    return {
        'input_ids': input_ids,
        'attention_mask': attention_mask,
        'labels': labels,
        'id': ids,
        'bfs': bfs_list,
        'sent': sents
    }

##############################################
# 2. Training and Evaluation Function
##############################################
def train_and_evaluate(train_path, val_path, test_path):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model_name = "facebook/bart-base"
    
    tokenizer = BartTokenizer.from_pretrained(model_name)
    special_tokens = {"additional_special_tokens": ["<NODE>", "<EDGE>"]}
    num_added = tokenizer.add_special_tokens(special_tokens)
    
    model = BartForConditionalGeneration.from_pretrained(model_name)
    if num_added > 0:
        model.resize_token_embeddings(len(tokenizer))
    model.to(device)

    train_dataset = AMRBartDataset(train_path, tokenizer)
    val_dataset = AMRBartDataset(val_path, tokenizer)
    test_dataset = AMRBartDataset(test_path, tokenizer)

    train_loader = DataLoader(train_dataset, batch_size=8, shuffle=True, collate_fn=collate_fn)
    val_loader = DataLoader(val_dataset, batch_size=8, shuffle=False, collate_fn=collate_fn)
    test_loader = DataLoader(test_dataset, batch_size=1, shuffle=False, collate_fn=collate_fn)

    optimizer = optim.AdamW(model.parameters(), lr=5e-5)
    num_epochs = 3

    for epoch in range(num_epochs):
        model.train()
        total_train_loss = 0.0
        for batch in tqdm(train_loader, desc=f"Training Epoch {epoch+1}"):
            optimizer.zero_grad()
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            labels = batch['labels'].to(device)
            outputs = model(input_ids=input_ids,
                            attention_mask=attention_mask,
                            labels=labels)
            loss = outputs.loss
            loss.backward()
            optimizer.step()
            total_train_loss += loss.item()
        avg_train_loss = total_train_loss / len(train_loader)
        print(f"Epoch {epoch+1} Train Loss: {avg_train_loss:.4f}")

        model.eval()
        total_val_loss = 0.0
        with torch.no_grad():
            for batch in tqdm(val_loader, desc=f"Validation Epoch {epoch+1}"):
                input_ids = batch['input_ids'].to(device)
                attention_mask = batch['attention_mask'].to(device)
                labels = batch['labels'].to(device)
                outputs = model(input_ids=input_ids,
                                attention_mask=attention_mask,
                                labels=labels)
                loss = outputs.loss
                total_val_loss += loss.item()
        avg_val_loss = total_val_loss / len(val_loader)
        print(f"Epoch {epoch+1} Validation Loss: {avg_val_loss:.4f}")

    model.eval()
    predictions_tokens = []
    references_tokens = []
    predictions_str = []
    references_str = []
    output_records = []

    with torch.no_grad():
        for batch in tqdm(test_loader, desc="Evaluating Test Set"):
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            generated_ids = model.generate(
                input_ids=input_ids,
                attention_mask=attention_mask,
                max_length=128,
                num_beams=5,
                early_stopping=True,
                decoder_start_token_id=model.config.decoder_start_token_id
            )
            pred_text = tokenizer.decode(generated_ids[0], skip_special_tokens=True)
            ref_text = tokenizer.decode(batch['labels'][0], skip_special_tokens=True)

            predictions_tokens.append(pred_text.split())
            references_tokens.append([ref_text.split()])
            predictions_str.append(pred_text)
            references_str.append(ref_text)

            output_records.append({
                "id": batch["id"][0],
                "bfs": batch["bfs"][0],
                "prediction": pred_text,
                "reference": ref_text
            })

            print("BFS:", batch["bfs"][0])
            print("Prediction:", pred_text)
            print("Reference:", ref_text, "\n")

    bleu_score = corpus_bleu(references_tokens, predictions_tokens)
    print(f"\nBLEU Score: {bleu_score:.4f}")

    rouge_evaluator = Rouge()
    rouge_scores = rouge_evaluator.get_scores(predictions_str, references_str, avg=True)
    print("ROUGE Scores:", rouge_scores)

    output_data = {
        "metrics": {
            "BLEU": bleu_score,
            "ROUGE": rouge_scores
        },
        "predictions": output_records
    }
    with open("output_predictions.json", "w", encoding="utf-8") as f:
        json.dump(output_data, f, ensure_ascii=False, indent=4)

    print("\nEvaluation complete. Results saved to output_predictions.json")

##############################################
# 3. Command-Line Entry Point
##############################################
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train and evaluate BART on BFS-to-English task")
    parser.add_argument('--train', type=str, required=True, help="Path to training JSON file")
    parser.add_argument('--val', type=str, required=True, help="Path to validation JSON file")
    parser.add_argument('--test', type=str, required=True, help="Path to test JSON file")
    args = parser.parse_args()

    train_and_evaluate(args.train, args.val, args.test)



# python bfs_train.py --train outputBFS_small_train.json --val outputBFS_small_dev.json --test outputBFS_small_test.json