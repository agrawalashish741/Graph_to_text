import json
import argparse

def convert_amr_to_txt(input_json_file, output_txt_file):
    # Load JSON data from file
    with open(input_json_file, "r", encoding="utf-8") as file:
        data = json.load(file)

    # Open output file for writing
    with open(output_txt_file, "w", encoding="utf-8") as f:
        for entry in data:
            # Extract relevant fields
            amr_id = entry.get("amrID", "unknown")
            sentence = entry.get("sent", "No sentence provided.")
            amr_graph = entry.get("amr", "")

            # Write to the file in Penman format
            f.write(f"# ::id {amr_id}\n")
            f.write(f"# ::snt {sentence}\n")
            f.write(f"{amr_graph}\n\n")  # Double newline to separate entries

    print(f"Conversion complete! Data saved in {output_txt_file}")

def main():
    # Set up argument parser
    parser = argparse.ArgumentParser(description="Convert AMR JSON files to Penman format text files.")
    parser.add_argument("--train", required=True, help="Input JSON file for training set.")
    parser.add_argument("--test", required=True, help="Input JSON file for test set.")
    parser.add_argument("--val", required=True, help="Input JSON file for validation set.")
    parser.add_argument("--output_dir", required=True, help="Directory to save the output text files.")

    # Parse arguments
    args = parser.parse_args()

    # Convert training, test, and validation data
    convert_amr_to_txt(args.train, f"{args.output_dir}/train.txt")
    convert_amr_to_txt(args.test, f"{args.output_dir}/test.txt")
    convert_amr_to_txt(args.val, f"{args.output_dir}/val.txt")

if __name__ == "__main__":
    main()

# python converted_amr_to_text.py --train ./data/amr_train.json --test ./data/amr_test.json --val ./data/amr_dev.json --output_dir ./output_texts