#!/usr/bin/env python
import os
import re
import traceback
import penman
import argparse

# === CONFIGURE HERE ===
MODE = "LINE_GRAPH"  # This will remain constant as per the provided script.
# =======================

# Function to create the required directories and perform preprocessing
def preprocess_amr(input_folder, output_dir):
    os.makedirs(output_dir, exist_ok=True)

    ##############################
    # Step 1: Splitting raw_amrs.txt into surface.txt.tok and graphs.txt
    def split_amr_align(input_path, out_surface_tok, out_graphs):
        with open(input_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        with open(out_surface_tok, 'w', encoding='utf-8') as surf_out, \
             open(out_graphs, 'w', encoding='utf-8') as graph_out:
            amr_mode = False; amr_tokens = []
            for line in lines:
                line = line.rstrip()
                if line.startswith("#"):
                    if amr_mode:
                        graph_out.write(" ".join(amr_tokens) + "\n")
                        amr_tokens = []; amr_mode = False
                    if line.startswith("# ::snt"):
                        surf_out.write(line.split(" ",2)[2] + "\n")
                elif line.strip():
                    amr_mode = True; amr_tokens.append(line.strip())
            if amr_mode:
                graph_out.write(" ".join(amr_tokens) + "\n")

    ##############################
    # Step 2: Detokenizer
    def detokenize_line(line):
        line = re.sub(r'\s+([,.?!])', r'\1', line)
        return line.strip()

    def detokenize_surface(input_tok, output_detok):
        with open(input_tok) as fin, open(output_detok, 'w') as fout:
            for l in fin:
                fout.write(detokenize_line(l) + "\n")

    ##############################
    # Step 3: LINE_GRAPH preprocessing (unchanged)
    SENSE_PATTERN = re.compile(r'-\d\d$')

    def simplify_2(tokens, v2c):
        mapping, new_tokens, save_map = {}, [], False
        for tok in tokens:
            if tok.startswith('('):
                last = tok.lstrip('('); continue
            if tok == '/':
                save_map = True; continue
            nt = tok.rstrip(')').split('~')[0]
            if nt:
                if nt in v2c:
                    mapping.setdefault(nt,set()).add(len(new_tokens))
                    if v2c[nt]: nt = v2c[nt]
                elif re.search(SENSE_PATTERN, nt):
                    nt = nt[:-3]
                new_tokens.append(nt)
            if save_map:
                mapping.setdefault(last,set()).add(len(new_tokens)-1)
                save_map=False
        return new_tokens, mapping

    def get_edge(tokens, edge, last, triple):
        for i in range(last+1, len(tokens)):
            if tokens[i]==edge: return i
        raise RuntimeError(f"Edge not found: {triple}")

    def get_line_graph(graph, tokens, mapping):
        triples, seen, eidx = [], set(), -1

        for src, rel, tgt in graph.triples:
            if rel in (':wiki', ':instance', ':instance-of'):
                continue

            # Flip “-of” relations
            if '-of' in rel:
                rel = rel + '-of'
                src, tgt = tgt, src

            # Skip relations not in our tokenised sequence
            if rel not in tokens:
                continue

            try:
                eidx = get_edge(tokens, rel, eidx, (src, rel, tgt))
            except RuntimeError:
                # If edge still can’t be found, skip it safely
                continue

            s_ids = sorted(mapping.get(str(src), []))
            t_ids = sorted(mapping.get(str(tgt), []))

            for s in s_ids:
                if (s, eidx, 'd') not in seen:
                    triples += [(s, eidx, 'd'), (eidx, s, 'r')]
                    seen.add((s, eidx, 'd'))
            for t in t_ids:
                if (eidx, t, 'd') not in seen:
                    triples += [(eidx, t, 'd'), (t, eidx, 'r')]
                    seen.add((eidx, t, 'd'))

        return tokens or ["<empty>"], sorted(triples)

    def create_instances(graph):
        return {inst.source:inst.target for inst in graph.instances()}

    ##############################
    # Run pipeline
    raw_path = os.path.join(output_dir, "raw_amrs.txt")
    surf_tok = os.path.join(output_dir, "surface.txt.tok")
    graphs_path = os.path.join(output_dir, "graphs.txt")
    surf_detok = os.path.join(output_dir, "surface.txt")

    # Read input files for train, test, and val
    for split in ['train', 'val', 'test']:
        split_folder = os.path.join(output_dir, split)
        os.makedirs(split_folder, exist_ok=True)

        input_file = os.path.join(input_folder, f"{split}.txt")
        raw_path = os.path.join(split_folder, "raw_amrs.txt")
        surf_tok = os.path.join(split_folder, "surface.txt.tok")
        graphs_path = os.path.join(split_folder, "graphs.txt")
        surf_detok = os.path.join(split_folder, "surface.txt")

        # Copy raw input
        with open(input_file) as fin, open(raw_path, 'w') as fout:
            fout.write(fin.read())

        split_amr_align(raw_path, surf_tok, graphs_path)
        detokenize_surface(surf_tok, surf_detok)

        final_src = os.path.join(split_folder, f"{split}.source")
        final_tgt = os.path.join(split_folder, f"{split}.target")
        final_graph = os.path.join(split_folder, f"{split}.graph")

        with open(graphs_path) as famr, open(surf_detok) as fs, \
             open(final_src, 'w') as out_src, open(final_tgt, 'w') as out_tgt, \
             open(final_graph, 'w') as out_graph:
            for amr_line, sent in zip(famr, fs):
                try:
                    graph = penman.decode(amr_line.strip())
                    tokens = amr_line.strip().split()
                    nodes, triples = get_line_graph(graph, *simplify_2(tokens, create_instances(graph)))
                    out_src.write(" ".join(nodes) + "\n")
                    out_graph.write(" ".join(f"({i},{j},{d})" for i, j, d in triples) + "\n")
                    out_tgt.write(sent)
                except Exception:
                    traceback.print_exc()

        print(f"✅ Done — check {split_folder}")

# CLI to provide input folder
def main():
    parser = argparse.ArgumentParser(description="Preprocess AMR data")
    parser.add_argument("--input_folder", required=True, help="Folder containing the input .txt files for train, val, and test datasets")
    parser.add_argument("--output_dir", required=True, help="Output directory where processed files will be saved")

    args = parser.parse_args()

    preprocess_amr(args.input_folder, args.output_dir)

if __name__ == "__main__":
    main()


# python Preproc.py --input_folder ./output_texts --output_dir ./preprocessed_data