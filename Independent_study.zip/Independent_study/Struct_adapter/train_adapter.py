import argparse
import json
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from transformers import BartTokenizer, BartForConditionalGeneration
from tqdm import tqdm
from nltk.translate.bleu_score import sentence_bleu
from rouge import Rouge
import os

# Dataset & Collate
class AMRDataset(Dataset):
    def __init__(self, graph_file, source_file, target_file=None, tokenizer=None, max_length=128):
        self.tokenizer = tokenizer
        with open(source_file, 'r', encoding='utf-8') as f:
            self.source_data = [line.strip() for line in f]
        with open(graph_file, 'r', encoding='utf-8') as f:
            self.graph_data = [line.strip() for line in f]
        assert len(self.graph_data) == len(self.source_data), "Source and graph lines must match"

        if target_file:
            with open(target_file, 'r', encoding='utf-8') as f:
                self.target_data = [line.strip() for line in f]
            assert len(self.target_data) == len(self.source_data), "Target lines must match source/graph"
        else:
            self.target_data = None

        self.max_length = max_length

    def __len__(self):
        return len(self.source_data)

    def __getitem__(self, idx):
        input_text = self.source_data[idx] + " " + self.graph_data[idx]
        inputs = self.tokenizer(
            input_text,
            return_tensors='pt',
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
        )
        if self.target_data:
            targets = self.tokenizer(
                self.target_data[idx],
                return_tensors='pt',
                max_length=self.max_length,
                padding='max_length',
                truncation=True,
            )
            return (
                inputs.input_ids.squeeze(0),
                inputs.attention_mask.squeeze(0),
                targets.input_ids.squeeze(0),
            )
        else:
            return (
                inputs.input_ids.squeeze(0),
                inputs.attention_mask.squeeze(0),
                None,
            )

def collate_fn(batch):
    input_ids, attention_masks, target_ids = zip(*batch)
    input_ids = torch.stack(input_ids, dim=0)
    attention_masks = torch.stack(attention_masks, dim=0)
    if target_ids[0] is not None:
        target_ids = torch.stack(target_ids, dim=0)
    else:
        target_ids = None
    return input_ids, attention_masks, target_ids

# Adapter Module
class Adapter(nn.Module):
    def __init__(self, hidden_size, adapter_size=64):
        super().__init__()
        self.down_proj = nn.Linear(hidden_size, adapter_size)
        self.activation = nn.ReLU()
        self.up_proj = nn.Linear(adapter_size, hidden_size)

    def forward(self, x):
        return x + self.up_proj(self.activation(self.down_proj(x)))

# Inject Adapters into BART
def inject_adapter_in_encoder_layer(layer, adapter_size=64):
    if hasattr(layer, 'old_forward'):
        return
    layer.old_forward = layer.forward
    hidden_dim = layer.self_attn.k_proj.out_features
    layer.adapter = Adapter(hidden_dim, adapter_size)

    def new_forward(self, hidden_states, *args, **kwargs):
        outputs = self.old_forward(hidden_states, *args, **kwargs)
        hidden_states = outputs[0]
        adapted = self.adapter(hidden_states)
        return (adapted,) + outputs[1:]

    layer.forward = new_forward.__get__(layer, type(layer))

def inject_adapter_in_decoder_layer(layer, adapter_size=64):
    if hasattr(layer, 'old_forward'):
        return
    layer.old_forward = layer.forward
    hidden_dim = layer.self_attn.k_proj.out_features
    layer.adapter = Adapter(hidden_dim, adapter_size)

    def new_forward(self, hidden_states, *args, **kwargs):
        outputs = self.old_forward(hidden_states, *args, **kwargs)
        hidden_states = outputs[0]
        adapted = self.adapter(hidden_states)
        return (adapted,) + outputs[1:]

    layer.forward = new_forward.__get__(layer, type(layer))

def add_adapters_to_bart(bart_model, adapter_size=64):
    for layer in bart_model.model.encoder.layers:
        inject_adapter_in_encoder_layer(layer, adapter_size)
    for layer in bart_model.model.decoder.layers:
        inject_adapter_in_decoder_layer(layer, adapter_size)

# Training & Evaluation
def train_and_evaluate(input_folder, output_folder, num_epochs):
    model_name = 'facebook/bart-base'
    tokenizer = BartTokenizer.from_pretrained(model_name)
    model = BartForConditionalGeneration.from_pretrained(model_name)

    for param in model.parameters():
        param.requires_grad = False

    add_adapters_to_bart(model, adapter_size=64)

    for module in model.modules():
        if isinstance(module, Adapter):
            for param in module.parameters():
                param.requires_grad = True

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)

    # Setup Dataset & Dataloaders
    train_dataset = AMRDataset(
        os.path.join(input_folder, 'train', 'train.graph'),
        os.path.join(input_folder, 'train', 'train.source'),
        os.path.join(input_folder, 'train', 'train.target'),
        tokenizer, max_length=128
    )
    val_dataset = AMRDataset(
        os.path.join(input_folder, 'val', 'val.graph'),
        os.path.join(input_folder, 'val', 'val.source'),
        os.path.join(input_folder, 'val', 'val.target'),
        tokenizer, max_length=128
    )
    test_dataset = AMRDataset(
        os.path.join(input_folder, 'test', 'test.graph'),
        os.path.join(input_folder, 'test', 'test.source'),
        os.path.join(input_folder, 'test', 'test.target'),
        tokenizer, max_length=128
    )

    train_loader = DataLoader(train_dataset, batch_size=8, shuffle=True, collate_fn=collate_fn)
    val_loader = DataLoader(val_dataset, batch_size=8, shuffle=False, collate_fn=collate_fn)
    test_loader = DataLoader(test_dataset, batch_size=1, shuffle=False, collate_fn=collate_fn)

    # Define optimizer
    adapter_params = [p for p in model.parameters() if p.requires_grad]
    if not adapter_params:
        raise ValueError("No adapter parameters found. Ensure injection is correct.")
    optimizer = optim.AdamW(adapter_params, lr=1e-4)

    # Training loop
    criterion = nn.CrossEntropyLoss(ignore_index=tokenizer.pad_token_id)

    for epoch in range(num_epochs):
        model.train()
        total_loss = 0.0
        for input_ids, attention_mask, target_ids in tqdm(train_loader, desc=f"Epoch {epoch+1}"):
            input_ids = input_ids.to(device)
            attention_mask = attention_mask.to(device)
            target_ids = target_ids.to(device)

            decoder_input_ids = target_ids[:, :-1].contiguous()
            labels = target_ids[:, 1:].clone()

            outputs = model(input_ids=input_ids, attention_mask=attention_mask, decoder_input_ids=decoder_input_ids)
            logits = outputs.logits
            loss = criterion(logits.view(-1, logits.size(-1)), labels.view(-1))
            loss.backward()
            optimizer.step()
            optimizer.zero_grad()

            total_loss += loss.item()

        avg_loss = total_loss / len(train_loader)
        print(f"Epoch {epoch+1} Training Loss: {avg_loss:.4f}")

        # Validation loop
        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for input_ids, attention_mask, target_ids in val_loader:
                input_ids = input_ids.to(device)
                attention_mask = attention_mask.to(device)
                target_ids = target_ids.to(device)

                decoder_input_ids = target_ids[:, :-1].contiguous()
                labels = target_ids[:, 1:].clone()

                outputs = model(input_ids=input_ids, attention_mask=attention_mask, decoder_input_ids=decoder_input_ids)
                logits = outputs.logits
                loss = criterion(logits.view(-1, logits.size(-1)), labels.view(-1))
                val_loss += loss.item()
        avg_val_loss = val_loss / len(val_loader)
        print(f"Epoch {epoch+1} Validation Loss: {avg_val_loss:.4f}")

    # Inference and Evaluation on Test set
    print("\nGenerating on test set...")
    model.eval()
    results = {}
    rouge = Rouge()  # initialize Rouge evaluator
    with torch.no_grad():
        for idx, (input_ids, attention_mask, target_ids) in enumerate(test_loader):
            input_ids = input_ids.to(device)
            attention_mask = attention_mask.to(device)

            generated_ids = model.generate(
                input_ids=input_ids,
                attention_mask=attention_mask,
                max_length=50,
                num_beams=5,
                early_stopping=True,
            )
            generated_text = tokenizer.decode(generated_ids[0], skip_special_tokens=True)
            actual_text = tokenizer.decode(target_ids[0], skip_special_tokens=True)
            bleu_score = sentence_bleu([actual_text.split()], generated_text.split())
            rouge_score = rouge.get_scores(generated_text, actual_text)[0]

            results[f"example_{idx}"] = {
                "predicted": generated_text,
                "actual": actual_text,
                "bleu": bleu_score,
                "rouge": rouge_score,
            }

    with open(os.path.join(output_folder, "result.json"), "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=4)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Train and evaluate a model with adapters for AMR data")
    parser.add_argument('--input_folder', type=str, required=True, help="Path to the folder containing train, val, and test data (with subfolders)")
    parser.add_argument('--output_folder', type=str, required=True, help="Path to the output folder where results will be saved")
    parser.add_argument('--epochs', type=int, required=True, help="Number of epochs for training")

    args = parser.parse_args()

    train_and_evaluate(args.input_folder, args.output_folder, args.epochs)


# python adapter_train.py --input_folder ./preprocessed_data --output_folder ./adapter_results --epochs 3
